HOME_URL = 'https://www.linkedin.com'
JOBS_URL = 'https://www.linkedin.com/jobs'
JOBS_SEARCH_URL = 'https://www.linkedin.com/jobs/search'
