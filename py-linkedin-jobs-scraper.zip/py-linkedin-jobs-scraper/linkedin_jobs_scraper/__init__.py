from linkedin_scraper import LinkedinScraper

# Define your query
query = Query(query="Software Engineer", options=QueryOptions(limit=10))

# Set up the scraper
scraper = LinkedinScraper(
    chrome_executable_path="/path/to/chromedriver",
    headless=True,
    max_workers=4
)

# Define a callback function to handle data
def handle_data(data):
    print("Data received:", data)

# Register the data event callback
scraper.on(event=Events.DATA, cb=handle_data)

# Run the scraper with your query
scraper.run(queries=query)